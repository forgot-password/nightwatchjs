let fs = require("fs");
let dir = "./downloads";

module.exports = {

    before: browser => {

        browser.url("https://github.com/forgot-password/nightwatchjs")
            .click('.get-repo-select-menu')
            .click('.get-repo-btn')
        for (let i = 0; i < 5; i++) {
            if (fs.existsSync(dir)) {
                break;
            }
            browser.pause(1000)
        }

    },

    'Download file': function (browser) {
        browser.verify.equal(fs.readdirSync(dir)[0], "nightwatchjs-master.zip")
    }
};